<?php include 'db_connect.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>FarEastern Airlines | Search</title>
    <style>
        /* --- BRANDING VARIABLES --- */
        :root { 
            --primary-green: #2E7D32; 
            --bg-color: #f4f7f6; 
            --logo-font: 'Trebuchet MS', sans-serif;
        }
        
        body { font-family: 'Segoe UI', sans-serif; background: var(--bg-color); margin: 0; }
        
        header { 
            background: var(--primary-green); 
            color: white; 
            padding: 1rem 2rem; 
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }

        /* Logo Style */
        header h2 {
            margin: 0;
            font-family: var(--logo-font);
            letter-spacing: 1px;
        }

        .container { max-width: 1000px; margin: 2rem auto; padding: 20px; }
        
        /* Search Box Styles */
        .search-box { background: white; padding: 2rem; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); display: flex; gap: 10px; align-items: flex-end; }
        .form-group { flex: 1; }
        .form-group label { font-weight: bold; font-size: 0.9rem; color: #333; display: block; margin-bottom: 5px;}
        input { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; }
        
        button { background: #ff9800; color: white; border: none; padding: 12px 20px; cursor: pointer; font-weight: bold; border-radius: 4px; transition: 0.3s;}
        button:hover { background: #e68900; }
        
        /* Flight Card Styles */
        .flight-card { background: white; border-left: 5px solid var(--primary-green); padding: 1.5rem; margin-top: 1rem; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }
        .price-tag { font-size: 1.5rem; color: var(--primary-green); font-weight: bold; }
        .book-btn { background: var(--primary-green); color: white; text-decoration: none; padding: 10px 20px; border-radius: 4px; display: inline-block;}
        .book-btn:hover { background: #1b5e20; }
    </style>
</head>
<body>

<header>
    <h2>✈️ FarEastern Airlines</h2>
</header>

<div class="container">
    <form class="search-box" method="GET" action="index.php">
        <div class="form-group">
            <label>From</label>
            <input type="text" name="from" placeholder="e.g. Manila" required>
        </div>
        <div class="form-group">
            <label>To</label>
            <input type="text" name="to" placeholder="e.g. Tokyo" required>
        </div>
        <button type="submit" name="search_btn">Find Flights</button>
    </form>

    <div class="results">
        <?php
        if (isset($_GET['search_btn'])) {
            $from = $_GET['from'];
            $to = $_GET['to'];

            $sql = "SELECT * FROM Flights WHERE departure_city LIKE ? AND arrival_city LIKE ?";
            $stmt = $conn->prepare($sql);
            
            $from_term = "%" . $from . "%";
            $to_term = "%" . $to . "%";
            $stmt->bind_param("ss", $from_term, $to_term);
            
            $stmt->execute();
            $result = $stmt->get_result();

            echo "<h3 style='margin-top:30px; color:#555;'>Available Flights:</h3>";

            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo '
                    <div class="flight-card">
                        <div>
                            <h3>' . $row["flight_number"] . '</h3>
                            <p><strong>' . $row["departure_city"] . '</strong> ➝ <strong>' . $row["arrival_city"] . '</strong></p>
                            <small style="color:#777;">Departure: ' . $row["departure_time"] . '</small>
                        </div>
                        <div style="text-align:right;">
                            <span class="price-tag">$' . $row["price"] . '</span>
                            <br><br>
                            <a href="book_flight.php?id=' . $row["flight_id"] . '" class="book-btn">Book Now</a>
                        </div>
                    </div>';
                }
            } else {
                echo "<p style='color: red;'>No flights found. Try searching for 'Manila' to 'Tokyo' or 'New York' to 'London'.</p>";
            }
        }
        ?>
    </div>
</div>

</body>
</html>