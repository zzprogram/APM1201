<?php include 'db_connect.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login | Far Eastern Airlines</title>
    <style>
        body { font-family: sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; background: #f4f7f6; }
        .login-box { background: white; padding: 40px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); text-align: center; }
        input { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ddd; border-radius: 4px; }
        button { background: #2E7D32; color: white; border: none; padding: 10px 20px; width: 100%; border-radius: 4px; cursor: pointer; }
        a { color: #2E7D32; text-decoration: none; }
    </style>
</head>
<body>

<div class="login-box">
    <h2 style="color: #2E7D32;">✈️ Login</h2>
    <form action="" method="POST">
        <input type="email" name="email" placeholder="Email Address" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Sign In</button>
    </form>
    <br>
    <p>Don't have an account? <a href="#">Sign Up</a></p>
    <br>
    <a href="front.php">← Back to Home</a>
</div>

</body>
</html>