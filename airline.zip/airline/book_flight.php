<?php
include 'db_connect.php';

if (isset($_GET['id'])) {
    $flight_id = $_GET['id'];
    $passenger_name = "Guest User"; 

    $sql = "INSERT INTO Bookings (flight_id, passenger_name, booking_date) VALUES (?, ?, NOW())";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("is", $flight_id, $passenger_name);

    if ($stmt->execute()) {
        echo "
        <div style='font-family: sans-serif; text-align: center; margin-top: 50px;'>
            <h1 style='color: #2E7D32;'>Thank you for choosing FarEastern! ✈️</h1>
            <p style='font-size: 1.2rem;'>Booking Confirmed.</p>
            <p>Flight Reference ID: <strong>$flight_id</strong></p>
            <a href='index.php' style='color: #ff9800; text-decoration: none; font-weight: bold;'>Book Another Flight</a>
        </div>";
    } else {
        echo "Error: " . $conn->error;
    }
} else {
    echo "No flight selected.";
}
?>