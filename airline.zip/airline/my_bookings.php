<?php include 'db_connect.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Bookings | Far Eastern Airlines</title>
    <style>
        /* Reuse your main styles */
        :root { --primary-green: #2E7D32; --bg-color: #f4f7f6; }
        body { font-family: 'Segoe UI', sans-serif; background: var(--bg-color); margin: 0; }
        header { background: var(--primary-green); color: white; padding: 1rem 2rem; display: flex; justify-content: space-between; align-items: center; }
        header a { color: white; text-decoration: none; margin-left: 20px; font-weight: 500; }
        
        .container { max-width: 1000px; margin: 2rem auto; padding: 20px; }
        
        table { width: 100%; border-collapse: collapse; background: white; box-shadow: 0 4px 6px rgba(0,0,0,0.1); border-radius: 8px; overflow: hidden; }
        th, td { padding: 15px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background-color: var(--primary-green); color: white; }
        tr:hover { background-color: #f1f1f1; }
        
        .cancel-btn { background-color: #d32f2f; color: white; border: none; padding: 5px 10px; border-radius: 4px; cursor: pointer; text-decoration: none; font-size: 0.9rem; }
        .cancel-btn:hover { background-color: #b71c1c; }
    </style>
</head>
<body>

<header>
    <h2>✈️ My Bookings</h2>
    <nav>
        <a href="front.php">Home</a>
        <a href="status.php">Flight Status</a>
    </nav>
</header>

<div class="container">
    <h2>Your Reserved Flights</h2>
    
    <table>
        <thead>
            <tr>
                <th>Booking ID</th>
                <th>Passenger</th>
                <th>Flight Info</th>
                <th>Date Booked</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // SQL JOIN: We connect Bookings and Flights tables to show flight details
            $sql = "SELECT Bookings.booking_id, Bookings.passenger_name, Bookings.booking_date, 
                           Flights.flight_number, Flights.departure_city, Flights.arrival_city 
                    FROM Bookings 
                    JOIN Flights ON Bookings.flight_id = Flights.flight_id";
            
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>#" . $row['booking_id'] . "</td>";
                    echo "<td>" . $row['passenger_name'] . "</td>";
                    echo "<td>" . $row['flight_number'] . " (" . $row['departure_city'] . " -> " . $row['arrival_city'] . ")</td>";
                    echo "<td>" . $row['booking_date'] . "</td>";
                    // THE DELETE BUTTON (Links to a delete script)
                    echo "<td><a href='cancel_booking.php?id=" . $row['booking_id'] . "' class='cancel-btn' onclick='return confirm(\"Are you sure?\")'>Cancel</a></td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='5'>No bookings found.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

</body>
</html>