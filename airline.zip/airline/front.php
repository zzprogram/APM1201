<?php 
// 1. CONNECT TO THE DATABASE
include 'db_connect.php'; 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Far Eastern Airlines | Booking System</title>
    <style>
        /* --- YOUR EXACT CSS STYLES --- */
        :root {
            --primary-green: #2E7D32;
            --dark-green: #1b5e20;
            --accent-orange: #ff9800;
            --bg-color: #f4f7f6;
            --text-dark: #333;
            --text-light: #fff;
            --shadow: 0 4px 6px rgba(0,0,0,0.1);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        body { background-color: var(--bg-color); color: var(--text-dark); }

        /* HEADER */
        header { background-color: var(--primary-green); color: var(--text-light); padding: 1rem 2rem; display: flex; justify-content: space-between; align-items: center; box-shadow: var(--shadow); }
        .logo { font-size: 1.5rem; font-weight: bold; display: flex; align-items: center; gap: 10px; }
        nav ul { list-style: none; display: flex; gap: 20px; }
        nav a { color: var(--text-light); text-decoration: none; font-weight: 500; transition: color 0.3s; }
        nav a:hover { color: var(--accent-orange); }
        .login-btn { background-color: var(--dark-green); padding: 8px 16px; border-radius: 4px; }

        /* MAIN CONTENT */
        .container { max-width: 1200px; margin: 0 auto; padding: 2rem; }

        /* SEARCH SECTION */
        .hero-section {
            background-image: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('https://images.unsplash.com/photo-1436491865332-7a61a109cc05?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80');
            background-size: cover; background-position: center; border-radius: 12px; padding: 4rem 2rem; text-align: center; color: white; margin-bottom: 2rem;
        }
        .search-box { background-color: white; padding: 2rem; border-radius: 8px; box-shadow: var(--shadow); margin-top: 2rem; display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; align-items: end; }
        .form-group { text-align: left; }
        .form-group label { display: block; margin-bottom: 5px; color: var(--text-dark); font-weight: bold; font-size: 0.9rem; }
        .form-group input, .form-group select { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; }
        .search-btn { background-color: var(--accent-orange); color: white; border: none; padding: 11px; border-radius: 4px; font-weight: bold; cursor: pointer; transition: background 0.3s; width: 100%; }
        .search-btn:hover { background-color: #e68900; }

        /* RESULTS SECTION */
        .results-section h2 { margin-bottom: 1rem; color: var(--primary-green); }
        .flight-card { background: white; border-left: 5px solid var(--primary-green); border-radius: 8px; padding: 1.5rem; margin-bottom: 1rem; display: flex; justify-content: space-between; align-items: center; box-shadow: var(--shadow); }
        .flight-info h3 { font-size: 1.2rem; margin-bottom: 5px; }
        .flight-route { color: #666; font-size: 0.9rem; }
        .flight-price { text-align: right; }
        .price-tag { font-size: 1.5rem; color: var(--primary-green); font-weight: bold; display: block; }
        
        /* Book Button Style Update */
        .book-btn { 
            background-color: var(--primary-green); color: white; border: none; padding: 8px 20px; border-radius: 4px; margin-top: 5px; cursor: pointer; text-decoration: none; display: inline-block; font-size: 0.9rem; 
        }
        .book-btn:hover { background-color: var(--dark-green); }
    </style>
</head>
<body>

    <header>
        <div class="logo">
            <span>✈️</span> Far Eastern Airlines
        </div>
        <nav>
            <ul>
                <li><a href="front.php">Home</a></li>
                <li><a href="my_bookings.php">My Bookings</a></li> 
                <li><a href="status.php">Flight Status</a></li>
                <li><a href="login.php" class="login-btn">Login / Sign Up</a></li>
            </ul>
        </nav>
    </header>

    <main class="container">
        
        <section class="hero-section">
            <h1>Explore the World with Comfort</h1>
            <p>Find the best deals on flights globally.</p>

            <form class="search-box" action="front.php" method="GET">
                <div class="form-group">
                    <label>From</label>
                    <input type="text" name="from" placeholder="City (e.g. Manila)" required>
                </div>
                <div class="form-group">
                    <label>To</label>
                    <input type="text" name="to" placeholder="City (e.g. Tokyo)" required>
                </div>
                <div class="form-group">
                    <label>Departure</label>
                    <input type="date" name="date">
                </div>
                <div class="form-group">
                    <label>Passengers</label>
                    <select name="passengers">
                        <option>1 Adult</option>
                        <option>2 Adults</option>
                        <option>Family (2A, 2C)</option>
                    </select>
                </div>
                <button type="submit" name="search_btn" class="search-box button search-btn">Search Flights</button>
            </form>
        </section>

        <section class="results-section">
            <?php
            // Check if the search button was clicked
            if (isset($_GET['search_btn'])) {
                $from = $_GET['from'];
                $to = $_GET['to'];

                echo "<h2>Available Flights for: " . htmlspecialchars($from) . " ➝ " . htmlspecialchars($to) . "</h2>";

                // Prepare the SQL (READ Operation)
                $sql = "SELECT * FROM Flights WHERE departure_city LIKE ? AND arrival_city LIKE ?";
                $stmt = $conn->prepare($sql);
                
                // Add wildcards for flexible search
                $from_term = "%" . $from . "%";
                $to_term = "%" . $to . "%";
                $stmt->bind_param("ss", $from_term, $to_term);
                
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    // LOOP through database results
                    while($row = $result->fetch_assoc()) {
            ?>
                        <div class="flight-card">
                            <div class="flight-info">
                                <h3><?php echo $row['flight_number']; ?></h3>
                                <p class="flight-route">
                                    <?php echo $row['departure_city']; ?> ➝ <?php echo $row['arrival_city']; ?> 
                                    • <?php echo $row['departure_time']; ?>
                                </p>
                            </div>
                            <div class="flight-price">
                                <span class="price-tag">$<?php echo $row['price']; ?></span>
                                <a href="book_flight.php?id=<?php echo $row['flight_id']; ?>" class="book-btn">Select Flight</a>
                            </div>
                        </div>
            <?php
                    } // End While Loop
                } else {
                    echo "<p>No flights found. Try <strong>Manila</strong> to <strong>Tokyo</strong>.</p>";
                }
            }
            ?>
        </section>
    </main>

</body>
</html>