<?php
include 'db_connect.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // DELETE QUERY
    $sql = "DELETE FROM Bookings WHERE booking_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        // Redirect back to My Bookings page
        header("Location: my_bookings.php");
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}
?>